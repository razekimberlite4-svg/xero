import "dotenv/config";
import express from "express";
import cors from "cors";
import crypto from "node:crypto";
import { query } from "./db.js";
import {
  hashPassword,
  verifyPassword,
  signToken,
  requireAuth,
} from "./auth.js";
import { trendingScore, risingScore, trendLabel } from "./ranking.js";

const app = express();
app.use(cors({ origin: process.env.CORS_ORIGIN || "*" }));
app.use(express.json({ limit: "1mb" }));

const uid = () => crypto.randomUUID();
const COLORS = ["#a855f7", "#d946ef", "#8b5cf6", "#ec4899", "#7c3aed", "#c026d3"];

function publicUser(row) {
  if (!row) return null;
  return {
    uid: row.uid,
    username: row.username,
    displayName: row.display_name,
    bio: row.bio,
    country: row.country,
    photoColor: row.photo_color,
    verified: row.verified,
    isUpdater: row.is_updater,
    joinedAt: Number(row.joined_at),
    following: row.following ?? [],
    followers: row.followers ?? [],
    savedPosts: row.saved_posts ?? [],
    followedCategories: row.followed_categories ?? [],
  };
}

function publicPost(row, comments = []) {
  return {
    id: row.id,
    authorId: row.author_id,
    title: row.title,
    body: row.body,
    category: row.category,
    hashtags: row.hashtags ?? [],
    link: row.link,
    source: row.source,
    imageSeed: row.image_seed,
    createdAt: Number(row.created_at),
    views: row.views,
    likes: row.likes ?? [],
    comments: comments.map((c) => ({
      id: c.id,
      authorId: c.author_id,
      body: c.body,
      createdAt: Number(c.created_at),
    })),
  };
}

async function notify(userId, text) {
  await query(
    "INSERT INTO notifications (id, user_id, text, read, created_at) VALUES ($1,$2,$3,false,$4)",
    [uid(), userId, text, Date.now()]
  );
}

// ---------- Auth ----------
app.post("/auth/register", async (req, res) => {
  const { username, displayName, email, password } = req.body ?? {};
  if (!username || !displayName || !email || !password)
    return res.status(400).json({ error: "All fields are required" });
  if (password.length < 8)
    return res.status(400).json({ error: "Password must be at least 8 characters" });
  if (!/^[a-zA-Z0-9_]{3,20}$/.test(username))
    return res.status(400).json({ error: "Username must be 3-20 letters, numbers, or underscores" });

  const existing = await query(
    "SELECT 1 FROM users WHERE LOWER(username)=LOWER($1) OR LOWER(email)=LOWER($2)",
    [username, email]
  );
  if (existing.rowCount > 0)
    return res.status(409).json({ error: "Username or email already in use" });

  const id = uid();
  const hash = await hashPassword(password);
  const color = COLORS[Math.floor(Math.random() * COLORS.length)];
  await query(
    `INSERT INTO users (uid, username, display_name, email, password_hash, photo_color, joined_at)
     VALUES ($1,$2,$3,$4,$5,$6,$7)`,
    [id, username, displayName, email, hash, color, Date.now()]
  );
  const row = (await query("SELECT * FROM users WHERE uid=$1", [id])).rows[0];
  res.json({ token: signToken(id), user: publicUser(row) });
});

app.post("/auth/login", async (req, res) => {
  const { email, password } = req.body ?? {};
  if (!email || !password)
    return res.status(400).json({ error: "Email and password are required" });
  const row = (
    await query("SELECT * FROM users WHERE LOWER(email)=LOWER($1)", [email])
  ).rows[0];
  if (!row || !(await verifyPassword(password, row.password_hash)))
    return res.status(401).json({ error: "Invalid email or password" });
  res.json({ token: signToken(row.uid), user: publicUser(row) });
});

app.get("/me", requireAuth, async (req, res) => {
  const row = (await query("SELECT * FROM users WHERE uid=$1", [req.uid])).rows[0];
  res.json(publicUser(row));
});

// ---------- Users ----------
app.get("/users/:id", async (req, res) => {
  const row = (await query("SELECT * FROM users WHERE uid=$1", [req.params.id])).rows[0];
  if (!row) return res.status(404).json({ error: "User not found" });
  res.json(publicUser(row));
});

app.patch("/me", requireAuth, async (req, res) => {
  const { displayName, bio, country } = req.body ?? {};
  await query(
    `UPDATE users SET
       display_name = COALESCE($2, display_name),
       bio = COALESCE($3, bio),
       country = COALESCE($4, country)
     WHERE uid=$1`,
    [req.uid, displayName ?? null, bio ?? null, country ?? null]
  );
  const row = (await query("SELECT * FROM users WHERE uid=$1", [req.uid])).rows[0];
  res.json(publicUser(row));
});

app.post("/users/:id/follow", requireAuth, async (req, res) => {
  const target = req.params.id;
  if (target === req.uid) return res.status(400).json({ error: "Cannot follow yourself" });
  const me = (await query("SELECT following FROM users WHERE uid=$1", [req.uid])).rows[0];
  const following = new Set(me.following ?? []);
  const isFollowing = following.has(target);
  if (isFollowing) following.delete(target);
  else following.add(target);

  await query("UPDATE users SET following=$2 WHERE uid=$1", [req.uid, [...following]]);
  await query(
    `UPDATE users SET followers = (
       SELECT array_agg(f.uid) FROM users f WHERE $1 = ANY(f.following)
     ) WHERE uid=$2`,
    [target, target]
  );
  if (!isFollowing) {
    const meRow = (await query("SELECT username FROM users WHERE uid=$1", [req.uid])).rows[0];
    await notify(target, `@${meRow.username} started following you`);
  }
  res.json({ following: [...following] });
});

// ---------- Posts ----------
app.get("/posts", async (req, res) => {
  const { category, cursor, sort } = req.query;
  const limit = 20;
  const params = [];
  let where = "WHERE 1=1";
  if (category && category !== "All") {
    params.push(category);
    where += ` AND category=$${params.length}`;
  }
  if (cursor) {
    params.push(Number(cursor));
    where += ` AND created_at < $${params.length}`;
  }
  params.push(limit);
  const rows = (
    await query(
      `SELECT * FROM posts ${where} ORDER BY created_at DESC LIMIT $${params.length}`,
      params
    )
  ).rows;

  const ids = rows.map((r) => r.id);
  const comments = ids.length
    ? (await query("SELECT * FROM comments WHERE post_id = ANY($1)", [ids])).rows
    : [];
  const byPost = {};
  for (const c of comments) (byPost[c.post_id] ??= []).push(c);

  let posts = rows.map((r) => publicPost(r, byPost[r.id] ?? []));
  const now = Date.now();
  if (sort === "trending") posts.sort((a, b) => trendingScore(b, now) - trendingScore(a, now));
  else if (sort === "rising") posts.sort((a, b) => risingScore(b, now) - risingScore(a, now));

  posts = posts.map((p) => ({ ...p, trendLabel: trendLabel(p, now) }));
  const nextCursor = rows.length === limit ? rows[rows.length - 1].created_at : undefined;
  res.json({ posts, nextCursor });
});

app.post("/posts", requireAuth, async (req, res) => {
  const { title, body, category, hashtags, link, source, imageSeed } = req.body ?? {};
  if (!title || title.length < 4) return res.status(400).json({ error: "Title too short" });
  if (!body || body.length < 10) return res.status(400).json({ error: "Body too short" });
  if (!category) return res.status(400).json({ error: "Category required" });
  if (link && !/^https?:\/\//.test(link))
    return res.status(400).json({ error: "Invalid link" });

  const id = uid();
  await query(
    `INSERT INTO posts (id, author_id, title, body, category, hashtags, link, source, image_seed, created_at)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)`,
    [id, req.uid, title, body, category, hashtags ?? [], link ?? null, source ?? null, imageSeed ?? null, Date.now()]
  );
  const row = (await query("SELECT * FROM posts WHERE id=$1", [id])).rows[0];
  res.json(publicPost(row));
});

app.post("/posts/:id/like", requireAuth, async (req, res) => {
  const post = (await query("SELECT * FROM posts WHERE id=$1", [req.params.id])).rows[0];
  if (!post) return res.status(404).json({ error: "Post not found" });
  const likes = new Set(post.likes ?? []);
  const liked = likes.has(req.uid);
  if (liked) likes.delete(req.uid);
  else likes.add(req.uid);
  await query("UPDATE posts SET likes=$2 WHERE id=$1", [post.id, [...likes]]);
  if (!liked && post.author_id !== req.uid) {
    const me = (await query("SELECT username FROM users WHERE uid=$1", [req.uid])).rows[0];
    await notify(post.author_id, `@${me.username} liked your update`);
  }
  res.json({ likes: [...likes] });
});

app.post("/posts/:id/view", async (req, res) => {
  await query("UPDATE posts SET views = views + 1 WHERE id=$1", [req.params.id]);
  res.json({ ok: true });
});

app.delete("/posts/:id", requireAuth, async (req, res) => {
  const post = (await query("SELECT author_id FROM posts WHERE id=$1", [req.params.id])).rows[0];
  if (!post) return res.status(404).json({ error: "Post not found" });
  if (post.author_id !== req.uid) return res.status(403).json({ error: "Not your post" });
  await query("DELETE FROM posts WHERE id=$1", [req.params.id]);
  res.json({ ok: true });
});

// ---------- Comments ----------
app.post("/posts/:id/comments", requireAuth, async (req, res) => {
  const { body } = req.body ?? {};
  if (!body || body.trim().length < 1)
    return res.status(400).json({ error: "Comment cannot be empty" });
  const post = (await query("SELECT author_id FROM posts WHERE id=$1", [req.params.id])).rows[0];
  if (!post) return res.status(404).json({ error: "Post not found" });
  const id = uid();
  await query(
    "INSERT INTO comments (id, post_id, author_id, body, created_at) VALUES ($1,$2,$3,$4,$5)",
    [id, req.params.id, req.uid, body.trim(), Date.now()]
  );
  if (post.author_id !== req.uid) {
    const me = (await query("SELECT username FROM users WHERE uid=$1", [req.uid])).rows[0];
    await notify(post.author_id, `@${me.username} commented on your update`);
  }
  const row = (await query("SELECT * FROM comments WHERE id=$1", [id])).rows[0];
  res.json({ id: row.id, authorId: row.author_id, body: row.body, createdAt: Number(row.created_at) });
});

// ---------- Saved posts ----------
app.post("/posts/:id/save", requireAuth, async (req, res) => {
  const me = (await query("SELECT saved_posts FROM users WHERE uid=$1", [req.uid])).rows[0];
  const saved = new Set(me.saved_posts ?? []);
  if (saved.has(req.params.id)) saved.delete(req.params.id);
  else saved.add(req.params.id);
  await query("UPDATE users SET saved_posts=$2 WHERE uid=$1", [req.uid, [...saved]]);
  res.json({ savedPosts: [...saved] });
});

// ---------- Notifications ----------
app.get("/notifications", requireAuth, async (req, res) => {
  const rows = (
    await query("SELECT * FROM notifications WHERE user_id=$1 ORDER BY created_at DESC LIMIT 50", [req.uid])
  ).rows;
  res.json(
    rows.map((n) => ({ id: n.id, text: n.text, read: n.read, createdAt: Number(n.created_at) }))
  );
});

app.post("/notifications/read", requireAuth, async (req, res) => {
  await query("UPDATE notifications SET read=true WHERE user_id=$1", [req.uid]);
  res.json({ ok: true });
});

// ---------- Trending ----------
app.get("/trending", async (req, res) => {
  const rows = (await query("SELECT * FROM posts ORDER BY created_at DESC LIMIT 200")).rows;
  const now = Date.now();
  const scored = rows
    .map((r) => ({ post: publicPost(r), score: trendingScore(r, now), rising: risingScore(r, now) }))
    .sort((a, b) => b.score - a.score);
  res.json({
    top: scored.slice(0, 10),
    rising: [...scored].sort((a, b) => b.rising - a.rising).slice(0, 10),
  });
});

app.get("/health", (_req, res) => res.json({ ok: true }));

const PORT = process.env.PORT || 4000;
app.listen(PORT, () => console.log(`Xero backend listening on :${PORT}`));