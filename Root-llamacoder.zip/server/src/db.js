import pg from "pg";

const { Pool } = pg;

// Render provides DATABASE_URL for managed Postgres.
// For local dev, set DATABASE_URL in a .env file.
export const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: process.env.DATABASE_URL?.includes("render.com")
    ? { rejectUnauthorized: false }
    : false,
});

export async function query(text, params) {
  const start = Date.now();
  const res = await pool.query(text, params);
  const duration = Date.now() - start;
  if (process.env.NODE_ENV !== "production") {
    console.log("query", { text, duration, rows: res.rowCount });
  }
  return res;
}