import "dotenv/config";
import { query, pool } from "./db.js";

const SCHEMA = `
CREATE TABLE IF NOT EXISTS users (
  uid           TEXT PRIMARY KEY,
  username      TEXT UNIQUE NOT NULL,
  display_name  TEXT NOT NULL,
  email         TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  bio           TEXT DEFAULT '',
  country       TEXT DEFAULT '',
  photo_color   TEXT DEFAULT '#a855f7',
  verified      BOOLEAN DEFAULT FALSE,
  is_updater    BOOLEAN DEFAULT TRUE,
  joined_at     BIGINT NOT NULL,
  following     TEXT[] DEFAULT '{}',
  followers     TEXT[] DEFAULT '{}',
  saved_posts   TEXT[] DEFAULT '{}',
  followed_categories TEXT[] DEFAULT '{}'
);

CREATE TABLE IF NOT EXISTS posts (
  id          TEXT PRIMARY KEY,
  author_id   TEXT NOT NULL REFERENCES users(uid) ON DELETE CASCADE,
  title       TEXT NOT NULL,
  body        TEXT NOT NULL,
  category    TEXT NOT NULL,
  hashtags    TEXT[] DEFAULT '{}',
  link        TEXT,
  source      TEXT,
  image_seed  TEXT,
  created_at  BIGINT NOT NULL,
  views       INTEGER DEFAULT 0,
  likes       TEXT[] DEFAULT '{}'
);

CREATE TABLE IF NOT EXISTS comments (
  id         TEXT PRIMARY KEY,
  post_id    TEXT NOT NULL REFERENCES posts(id) ON DELETE CASCADE,
  author_id  TEXT NOT NULL REFERENCES users(uid) ON DELETE CASCADE,
  body       TEXT NOT NULL,
  created_at BIGINT NOT NULL
);

CREATE TABLE IF NOT EXISTS notifications (
  id         TEXT PRIMARY KEY,
  user_id    TEXT NOT NULL REFERENCES users(uid) ON DELETE CASCADE,
  text       TEXT NOT NULL,
  read       BOOLEAN DEFAULT FALSE,
  created_at BIGINT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_posts_created ON posts (created_at DESC);
CREATE INDEX IF NOT EXISTS idx_posts_category ON posts (category);
CREATE INDEX IF NOT EXISTS idx_comments_post ON comments (post_id);
CREATE INDEX IF NOT EXISTS idx_notifications_user ON notifications (user_id);
`;

async function migrate() {
  console.log("Running migrations…");
  await query(SCHEMA);
  console.log("Migrations complete.");
  await pool.end();
}

migrate().catch((err) => {
  console.error("Migration failed:", err);
  process.exit(1);
});