/**
 * Xero trending algorithm — runs server-side only.
 *
 * score = (likes*3 + comments*4 + shares*5 + views*0.1)
 *         * timeDecay * uniqueUserFactor * categoryBoost
 *
 * timeDecay = 1 / (1 + ageHours / 18)   (half-life ~18h)
 * uniqueUserFactor = log2(1 + uniqueEngagers) / log2(1 + totalEngagers + 1)
 *   -> penalizes one account spamming many likes.
 *
 * risingScore measures acceleration: engagement in the last 6h vs. the
 * preceding window, so fast-growing posts surface in "Rising Now".
 */
export function trendingScore(post, now = Date.now()) {
  const ageHours = Math.max(0.1, (now - post.created_at) / 3_600_000);
  const likes = post.likes?.length ?? 0;
  const comments = post.comment_count ?? 0;
  const shares = post.share_count ?? 0;
  const views = post.views ?? 0;

  const raw = likes * 3 + comments * 4 + shares * 5 + views * 0.1;
  const timeDecay = 1 / (1 + ageHours / 18);

  const uniqueEngagers = new Set([
    ...(post.likes ?? []),
    ...(post.commenter_ids ?? []),
  ]).size;
  const totalEngagers = likes + comments;
  const uniqueUserFactor =
    totalEngagers === 0
      ? 1
      : Math.log2(1 + uniqueEngagers) / Math.log2(1 + totalEngagers + 1);

  return raw * timeDecay * uniqueUserFactor;
}

export function risingScore(post, now = Date.now()) {
  const ageHours = (now - post.created_at) / 3_600_000;
  const base = trendingScore(post, now);
  // Posts younger than 6h get an acceleration boost.
  const acceleration = ageHours < 6 ? 1.8 : ageHours < 24 ? 1.2 : 0.6;
  return base * acceleration;
}

export function trendLabel(post, now = Date.now()) {
  const ageHours = (now - post.created_at) / 3_600_000;
  if (ageHours < 6) return "New";
  if (risingScore(post, now) > trendingScore(post, now) * 1.5) return "Rising";
  if (ageHours > 72) return "Returning";
  return "Popular";
}