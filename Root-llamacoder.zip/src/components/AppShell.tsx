import { useMemo, useState } from "react";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Flame,
  Search,
  Plus,
  Bell,
  LogOut,
  Home,
  Compass,
  Bookmark,
  User as UserIcon,
  TrendingUp,
  Sparkles,
  RotateCcw,
  Clock,
  Users,
  X,
  Check,
  Pencil,
} from "lucide-react";
import {
  useAuth,
  CATEGORIES,
  initials,
  timeAgo,
  trendingScore,
  risingScore,
  type Category,
  type Post,
} from "@/lib/store";
import { PostCard } from "@/components/PostCard";
import { toast } from "sonner";

type Tab = "home" | "discover" | "saved" | "profile";

export function AppShell() {
  const {
    user,
    state,
    logout,
    createPost,
    toggleFollow,
    toggleCategory,
    updateProfile,
    readNotifications,
    userById,
  } = useAuth();

  const [tab, setTab] = useState<Tab>("home");
  const [search, setSearch] = useState("");
  const [activeCategory, setActiveCategory] = useState<Category | "All">("All");
  const [composerOpen, setComposerOpen] = useState(false);
  const [notifOpen, setNotifOpen] = useState(false);
  const [viewingUid, setViewingUid] = useState<string | null>(null);

  const now = Date.now();

  const myNotifications = useMemo(
    () => state.notifications.filter((n) => n.userId === user?.uid),
    [state.notifications, user?.uid]
  );
  const unread = myNotifications.filter((n) => !n.read).length;

  const filtered = useMemo(() => {
    let posts = [...state.posts];
    if (activeCategory !== "All") posts = posts.filter((p) => p.category === activeCategory);
    if (search.trim()) {
      const q = search.toLowerCase();
      posts = posts.filter(
        (p) =>
          p.title.toLowerCase().includes(q) ||
          p.body.toLowerCase().includes(q) ||
          p.hashtags.some((h) => h.toLowerCase().includes(q)) ||
          userById(p.authorId)?.username.toLowerCase().includes(q) ||
          userById(p.authorId)?.displayName.toLowerCase().includes(q)
      );
    }
    return posts;
  }, [state.posts, activeCategory, search, userById]);

  const trending = useMemo(
    () => [...filtered].sort((a, b) => trendingScore(b, now) - trendingScore(a, now)).slice(0, 5),
    [filtered, now]
  );
  const rising = useMemo(
    () => [...filtered].sort((a, b) => risingScore(b, now) - risingScore(a, now)).slice(0, 4),
    [filtered, now]
  );
  const recent = useMemo(
    () => [...filtered].sort((a, b) => b.createdAt - a.createdAt),
    [filtered]
  );
  const followingFeed = useMemo(() => {
    if (!user) return recent;
    const ids = new Set(user.following);
    const feed = recent.filter((p) => ids.has(p.authorId));
    return feed.length ? feed : recent;
  }, [recent, user]);

  const recommendedUpdaters = useMemo(() => {
    if (!user) return [];
    return [...state.users]
      .filter((u) => u.uid !== user.uid && !user.following.includes(u.uid))
      .sort((a, b) => b.followers.length - a.followers.length)
      .slice(0, 4);
  }, [state.users, user]);

  const savedPosts = useMemo(
    () => state.posts.filter((p) => user?.savedPosts.includes(p.id)),
    [state.posts, user?.savedPosts]
  );

  const viewingUser = viewingUid ? userById(viewingUid) : null;
  const viewingPosts = viewingUser
    ? state.posts.filter((p) => p.authorId === viewingUser.uid).sort((a, b) => b.createdAt - a.createdAt)
    : [];

  if (!user) return null;

  const openAuthor = (uid: string) => {
    setViewingUid(uid);
    setTab("profile");
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-950 via-fuchsia-950 to-violet-950 text-purple-50">
      {/* Header */}
      <header className="sticky top-0 z-40 border-b border-purple-800/50 bg-purple-950/80 backdrop-blur">
        <div className="mx-auto flex max-w-6xl items-center gap-3 px-4 py-3">
          <button onClick={() => { setTab("home"); setViewingUid(null); }} className="flex items-center gap-2">
            <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-fuchsia-500 via-purple-500 to-violet-600">
              <Flame className="h-5 w-5 text-white" />
            </div>
            <span className="hidden font-serif text-xl font-bold text-fuchsia-50 sm:inline">Xero</span>
          </button>

          <div className="relative mx-auto w-full max-w-md">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-purple-400" />
            <Input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search posts, people, #hashtags…"
              className="border-purple-700 bg-purple-900/50 pl-9 text-purple-50 placeholder:text-purple-400"
            />
          </div>

          <Button
            onClick={() => setComposerOpen(true)}
            className="hidden bg-gradient-to-r from-fuchsia-500 via-purple-500 to-violet-600 text-white hover:from-fuchsia-600 hover:via-purple-600 hover:to-violet-700 sm:flex"
          >
            <Plus className="h-4 w-4" /> Update
          </Button>

          <div className="relative">
            <button
              onClick={() => {
                setNotifOpen((o) => !o);
                if (!notifOpen) readNotifications();
              }}
              className="relative rounded-lg p-2 text-purple-300 transition hover:bg-purple-900/60 hover:text-purple-50"
            >
              <Bell className="h-5 w-5" />
              {unread > 0 && (
                <span className="absolute right-1 top-1 flex h-4 min-w-4 items-center justify-center rounded-full bg-fuchsia-500 px-1 text-xs font-bold text-white">
                  {unread}
                </span>
              )}
            </button>
            {notifOpen && (
              <div className="absolute right-0 mt-2 w-80 rounded-xl border border-purple-800/60 bg-purple-950 p-2 shadow-2xl">
                <div className="px-2 py-1.5 text-sm font-semibold text-purple-200">Notifications</div>
                <div className="max-h-80 overflow-y-auto">
                  {myNotifications.length === 0 && (
                    <p className="px-2 py-6 text-center text-sm text-purple-400">No notifications yet.</p>
                  )}
                  {myNotifications.map((n) => (
                    <div key={n.id} className="rounded-lg px-2 py-2 text-sm hover:bg-purple-900/60">
                      <p className="text-purple-100">{n.text}</p>
                      <span className="text-xs text-purple-400">{timeAgo(n.createdAt)}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          <button
            onClick={() => { setViewingUid(user.uid); setTab("profile"); }}
            className="shrink-0"
          >
            <Avatar className="h-9 w-9 border border-purple-700/60">
              <AvatarFallback style={{ background: user.photoColor }} className="text-xs font-bold text-white">
                {initials(user.displayName)}
              </AvatarFallback>
            </Avatar>
          </button>
        </div>
      </header>

      {/* Nav tabs */}
      <nav className="border-b border-purple-800/50 bg-purple-900/30">
        <div className="mx-auto flex max-w-6xl gap-1 px-4">
          {([
            { id: "home", label: "Home", icon: Home },
            { id: "discover", label: "Discover", icon: Compass },
            { id: "saved", label: "Saved", icon: Bookmark },
            { id: "profile", label: "Profile", icon: UserIcon },
          ] as const).map((t) => (
            <button
              key={t.id}
              onClick={() => { setTab(t.id); if (t.id !== "profile") setViewingUid(null); if (t.id === "profile") setViewingUid(user.uid); }}
              className={`flex items-center gap-2 border-b-2 px-4 py-3 text-sm font-medium transition ${
                tab === t.id
                  ? "border-fuchsia-500 text-fuchsia-400"
                  : "border-transparent text-purple-300 hover:text-purple-100"
              }`}
            >
              <t.icon className="h-4 w-4" />
              {t.label}
            </button>
          ))}
          <button
            onClick={logout}
            className="ml-auto flex items-center gap-2 px-4 py-3 text-sm font-medium text-purple-300 transition hover:text-red-400"
          >
            <LogOut className="h-4 w-4" /> Sign out
          </button>
        </div>
      </nav>

      <main className="mx-auto max-w-6xl px-4 py-6">
        {tab === "home" && (
          <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
            <div className="space-y-6 lg:col-span-2">
              {/* Category chips */}
              <div className="flex flex-wrap gap-2">
                <button
                  onClick={() => setActiveCategory("All")}
                  className={`rounded-full px-3 py-1.5 text-sm transition ${
                    activeCategory === "All"
                      ? "bg-gradient-to-r from-fuchsia-500 to-violet-600 text-white"
                      : "border border-purple-700 bg-purple-900/40 text-purple-200 hover:border-fuchsia-500/60"
                  }`}
                >
                  All
                </button>
                {CATEGORIES.map((c) => (
                  <button
                    key={c}
                    onClick={() => setActiveCategory(c)}
                    className={`rounded-full px-3 py-1.5 text-sm transition ${
                      activeCategory === c
                        ? "bg-gradient-to-r from-fuchsia-500 to-violet-600 text-white"
                        : "border border-purple-700 bg-purple-900/40 text-purple-200 hover:border-fuchsia-500/60"
                    }`}
                  >
                    {c}
                  </button>
                ))}
              </div>

              {/* Hero band */}
              <div className="relative overflow-hidden rounded-2xl border border-purple-800/50 bg-gradient-to-br from-fuchsia-950/70 via-purple-950 to-violet-950 p-6">
                <div className="pointer-events-none absolute -right-10 -top-10 h-40 w-40 rounded-full bg-fuchsia-600/30 blur-3xl" />
                <div className="relative">
                  <div className="flex items-center gap-2 text-fuchsia-400">
                    <TrendingUp className="h-4 w-4" />
                    <span className="text-xs font-semibold uppercase tracking-wider">Trending Now</span>
                  </div>
                  <h2 className="mt-2 font-serif text-2xl font-bold text-fuchsia-50">
                    What the world is rising toward today
                  </h2>
                  <p className="mt-1 max-w-lg text-sm text-purple-300">
                    Ranked by a transparent time-decay algorithm on trusted server-side scoring. Updated as
                    engagement grows.
                  </p>
                </div>
              </div>

              {/* Trending list */}
              <section className="space-y-3">
                <h3 className="flex items-center gap-2 font-serif text-lg font-bold text-purple-50">
                  <Flame className="h-5 w-5 text-fuchsia-500" /> Top Trending
                </h3>
                {trending.map((p, i) => (
                  <div key={p.id} className="flex items-start gap-3">
                    <span className="mt-1 font-serif text-2xl font-bold text-purple-700">{i + 1}</span>
                    <div className="flex-1">
                      <PostCard post={p} onOpenAuthor={openAuthor} />
                    </div>
                  </div>
                ))}
                {trending.length === 0 && <EmptyState label="No trending updates match your filters." />}
              </section>

              {/* Rising */}
              <section className="space-y-3">
                <h3 className="flex items-center gap-2 font-serif text-lg font-bold text-purple-50">
                  <Sparkles className="h-5 w-5 text-emerald-400" /> Rising Now
                </h3>
                <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                  {rising.map((p) => (
                    <MiniTrend key={p.id} post={p} onOpenAuthor={openAuthor} />
                  ))}
                </div>
                {rising.length === 0 && <EmptyState label="Nothing accelerating right now." />}
              </section>

              {/* Recently posted */}
              <section className="space-y-3">
                <h3 className="flex items-center gap-2 font-serif text-lg font-bold text-purple-50">
                  <Clock className="h-5 w-5 text-sky-400" /> Recently Posted
                </h3>
                {followingFeed.slice(0, 8).map((p) => (
                  <PostCard key={p.id} post={p} onOpenAuthor={openAuthor} />
                ))}
              </section>
            </div>

            {/* Sidebar */}
            <aside className="space-y-6">
              <Card className="border-purple-800/50 bg-purple-950/40">
                <CardContent className="p-5">
                  <h3 className="flex items-center gap-2 font-serif text-base font-bold text-purple-50">
                    <Users className="h-4 w-4 text-fuchsia-500" /> Recommended Updaters
                  </h3>
                  <div className="mt-4 space-y-3">
                    {recommendedUpdaters.map((u) => (
                      <div key={u.uid} className="flex items-center gap-3">
                        <button onClick={() => openAuthor(u.uid)}>
                          <Avatar className="h-9 w-9">
                            <AvatarFallback style={{ background: u.photoColor }} className="text-xs font-bold text-white">
                              {initials(u.displayName)}
                            </AvatarFallback>
                          </Avatar>
                        </button>
                        <div className="min-w-0 flex-1">
                          <button onClick={() => openAuthor(u.uid)} className="block truncate text-sm font-medium text-purple-100 hover:text-fuchsia-400">
                            {u.displayName}
                          </button>
                          <span className="text-xs text-purple-400">@{u.username}</span>
                        </div>
                        <Button
                          size="sm"
                          onClick={() => toggleFollow(u.uid)}
                          className="bg-gradient-to-r from-fuchsia-500 to-violet-600 text-white hover:from-fuchsia-600 hover:to-violet-700"
                        >
                          Follow
                        </Button>
                      </div>
                    ))}
                    {recommendedUpdaters.length === 0 && (
                      <p className="text-sm text-purple-400">You follow everyone already.</p>
                    )}
                  </div>
                </CardContent>
              </Card>

              <Card className="border-purple-800/50 bg-purple-950/40">
                <CardContent className="p-5">
                  <h3 className="font-serif text-base font-bold text-purple-50">Follow Categories</h3>
                  <div className="mt-3 flex flex-wrap gap-2">
                    {CATEGORIES.map((c) => {
                      const on = user.followedCategories.includes(c);
                      return (
                        <button
                          key={c}
                          onClick={() => toggleCategory(c)}
                          className={`rounded-full px-3 py-1 text-xs transition ${
                            on
                              ? "bg-fuchsia-500/20 text-fuchsia-300 ring-1 ring-fuchsia-500/40"
                              : "border border-purple-700 text-purple-300 hover:border-fuchsia-500/40"
                          }`}
                        >
                          {on && <Check className="mr-1 inline h-3 w-3" />}
                          {c}
                        </button>
                      );
                    })}
                  </div>
                </CardContent>
              </Card>

              <Card className="border-purple-800/50 bg-gradient-to-br from-violet-950/60 to-purple-950">
                <CardContent className="p-5">
                  <h3 className="flex items-center gap-2 font-serif text-base font-bold text-violet-300">
                    <RotateCcw className="h-4 w-4" /> Xero Rising
                  </h3>
                  <p className="mt-2 text-sm text-purple-300">
                    Older topics gaining renewed engagement. We only surface a resurgence when stored
                    history supports it.
                  </p>
                  <div className="mt-3 space-y-2">
                    {state.posts
                      .filter((p) => (now - p.createdAt) / 3600000 > 40 && risingScore(p, now) > 0.5)
                      .slice(0, 3)
                      .map((p) => (
                        <div key={p.id} className="rounded-lg bg-purple-900/50 px-3 py-2">
                          <p className="truncate text-sm text-purple-100">{p.title}</p>
                          <span className="text-xs text-violet-400">Returning · ↑{Math.round(risingScore(p, now))}</span>
                        </div>
                      ))}
                    {state.posts.filter((p) => (now - p.createdAt) / 3600000 > 40 && risingScore(p, now) > 0.5).length === 0 && (
                      <p className="text-sm text-purple-400">No returning trends detected yet.</p>
                    )}
                  </div>
                </CardContent>
              </Card>
            </aside>
          </div>
        )}

        {tab === "discover" && (
          <div className="space-y-6">
            <div>
              <h2 className="font-serif text-2xl font-bold text-fuchsia-50">Discover</h2>
              <p className="text-sm text-purple-300">Browse categories, search trends, and find updaters.</p>
            </div>
            <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4">
              {CATEGORIES.map((c) => {
                const count = state.posts.filter((p) => p.category === c).length;
                return (
                  <button
                    key={c}
                    onClick={() => { setActiveCategory(c); setTab("home"); }}
                    className="rounded-xl border border-purple-800/50 bg-purple-950/40 p-4 text-left transition hover:border-fuchsia-500/60 hover:bg-purple-900/40"
                  >
                    <div className="font-medium text-purple-50">{c}</div>
                    <div className="mt-1 text-xs text-purple-400">{count} updates</div>
                  </button>
                );
              })}
            </div>
            <section className="space-y-3">
              <h3 className="font-serif text-lg font-bold text-purple-50">Popular Creators</h3>
              <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                {[...state.users]
                  .sort((a, b) => b.followers.length - a.followers.length)
                  .slice(0, 6)
                  .map((u) => (
                    <div key={u.uid} className="flex items-center gap-3 rounded-xl border border-purple-800/50 bg-purple-950/40 p-4">
                      <Avatar className="h-10 w-10">
                        <AvatarFallback style={{ background: u.photoColor }} className="text-sm font-bold text-white">
                          {initials(u.displayName)}
                        </AvatarFallback>
                      </Avatar>
                      <div className="min-w-0 flex-1">
                        <button onClick={() => openAuthor(u.uid)} className="block truncate font-medium text-purple-100 hover:text-fuchsia-400">
                          {u.displayName}
                        </button>
                        <span className="text-xs text-purple-400">
                          {u.followers.length} followers · {state.posts.filter((p) => p.authorId === u.uid).length} updates
                        </span>
                      </div>
                      {u.uid !== user.uid && (
                        <Button
                          size="sm"
                          variant={user.following.includes(u.uid) ? "outline" : "default"}
                          onClick={() => toggleFollow(u.uid)}
                          className={user.following.includes(u.uid) ? "border-purple-700 text-purple-200" : "bg-gradient-to-r from-fuchsia-500 to-violet-600 text-white hover:from-fuchsia-600 hover:to-violet-700"}
                        >
                          {user.following.includes(u.uid) ? "Following" : "Follow"}
                        </Button>
                      )}
                    </div>
                  ))}
              </div>
            </section>
          </div>
        )}

        {tab === "saved" && (
          <div className="space-y-4">
            <h2 className="font-serif text-2xl font-bold text-fuchsia-50">Saved Updates</h2>
            {savedPosts.length === 0 ? (
              <EmptyState label="You haven't saved any updates yet. Tap the bookmark on a post." />
            ) : (
              savedPosts.map((p) => <PostCard key={p.id} post={p} onOpenAuthor={openAuthor} />)
            )}
          </div>
        )}

        {tab === "profile" && (
          <ProfileView
            viewingUid={viewingUid ?? user.uid}
            posts={viewingPosts}
            onOpenAuthor={openAuthor}
          />
        )}
      </main>

      {/* Composer */}
      {composerOpen && (
        <Composer
          onClose={() => setComposerOpen(false)}
          onSubmit={(data) => {
            createPost(data);
            setComposerOpen(false);
            toast.success("Update published to Xero");
          }}
        />
      )}
    </div>
  );
}

function MiniTrend({ post, onOpenAuthor }: { post: Post; onOpenAuthor: (uid: string) => void }) {
  const { userById } = useAuth();
  const author = userById(post.authorId);
  return (
    <div className="rounded-xl border border-purple-800/50 bg-purple-950/40 p-4 transition hover:border-emerald-500/40">
      <div className="flex items-center gap-2">
        <Avatar className="h-6 w-6">
          <AvatarFallback style={{ background: author?.photoColor ?? "#a855f7" }} className="text-xs text-white">
            {initials(author?.displayName ?? "?")}
          </AvatarFallback>
        </Avatar>
        <button onClick={() => onOpenAuthor(post.authorId)} className="text-xs text-purple-300 hover:text-fuchsia-400">
          @{author?.username}
        </button>
        <span className="ml-auto text-xs text-emerald-400">↑{Math.round(risingScore(post))}</span>
      </div>
      <p className="mt-2 line-clamp-2 text-sm font-medium text-purple-100">{post.title}</p>
      <Badge variant="outline" className="mt-2 border-purple-700 text-xs text-purple-300">
        {post.category}
      </Badge>
    </div>
  );
}

function EmptyState({ label }: { label: string }) {
  return (
    <div className="rounded-2xl border border-dashed border-purple-800/60 bg-purple-950/30 p-10 text-center">
      <Flame className="mx-auto h-8 w-8 text-purple-700" />
      <p className="mt-3 text-sm text-purple-400">{label}</p>
    </div>
  );
}

function Composer({
  onClose,
  onSubmit,
}: {
  onClose: () => void;
  onSubmit: (data: {
    title: string;
    body: string;
    category: Category;
    hashtags: string[];
    link?: string;
    source?: string;
    imageSeed?: string;
  }) => void;
}) {
  const [title, setTitle] = useState("");
  const [body, setBody] = useState("");
  const [category, setCategory] = useState<Category>("Technology");
  const [hashtags, setHashtags] = useState("");
  const [link, setLink] = useState("");
  const [source, setSource] = useState("");
  const [withImage, setWithImage] = useState(false);
  const [error, setError] = useState("");

  const submit = () => {
    setError("");
    if (title.trim().length < 4) return setError("Title must be at least 4 characters.");
    if (body.trim().length < 10) return setError("Body must be at least 10 characters.");
    if (link && !/^https?:\/\//.test(link)) return setError("Link must start with http:// or https://");
    const tags = hashtags
      .split(/[\s,]+/)
      .map((t) => t.replace(/^#/, "").trim())
      .filter(Boolean)
      .slice(0, 6);
    onSubmit({
      title: title.trim(),
      body: body.trim(),
      category,
      hashtags: tags,
      link: link.trim() || undefined,
      source: source.trim() || undefined,
      imageSeed: withImage ? `phx-${Date.now()}` : undefined,
    });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-4 backdrop-blur-sm">
      <div className="w-full max-w-lg rounded-2xl border border-purple-800/60 bg-purple-950 shadow-2xl">
        <div className="flex items-center justify-between border-b border-purple-800/60 px-5 py-4">
          <h3 className="font-serif text-lg font-bold text-fuchsia-50">Create Update</h3>
          <button onClick={onClose} className="rounded-lg p-1.5 text-purple-300 hover:bg-purple-900/60 hover:text-purple-50">
            <X className="h-5 w-5" />
          </button>
        </div>
        <div className="max-h-[70vh] space-y-4 overflow-y-auto p-5">
          <div className="space-y-2">
            <Label className="text-purple-200">Title</Label>
            <Input
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="What's the trend?"
              className="border-purple-700 bg-purple-900/50 text-purple-50 placeholder:text-purple-400"
            />
          </div>
          <div className="space-y-2">
            <Label className="text-purple-200">Content</Label>
            <Textarea
              value={body}
              onChange={(e) => setBody(e.target.value)}
              rows={4}
              placeholder="Share the details, context, and why it matters…"
              className="border-purple-700 bg-purple-900/50 text-purple-50 placeholder:text-purple-400"
            />
          </div>
          <div className="space-y-2">
            <Label className="text-purple-200">Category</Label>
            <Select value={category} onValueChange={(v) => setCategory(v as Category)}>
              <SelectTrigger className="border-purple-700 bg-purple-900/50 text-purple-50">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="border-purple-700 bg-purple-950 text-purple-50">
                {CATEGORIES.map((c) => (
                  <SelectItem key={c} value={c}>{c}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <Label className="text-purple-200">Hashtags (space or comma separated)</Label>
            <Input
              value={hashtags}
              onChange={(e) => setHashtags(e.target.value)}
              placeholder="ai rising viral"
              className="border-purple-700 bg-purple-900/50 text-purple-50 placeholder:text-purple-400"
            />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-2">
              <Label className="text-purple-200">External link (optional)</Label>
              <Input
                value={link}
                onChange={(e) => setLink(e.target.value)}
                placeholder="https://…"
                className="border-purple-700 bg-purple-900/50 text-purple-50 placeholder:text-purple-400"
              />
            </div>
            <div className="space-y-2">
              <Label className="text-purple-200">Source (optional)</Label>
              <Input
                value={source}
                onChange={(e) => setSource(e.target.value)}
                placeholder="Reuters"
                className="border-purple-700 bg-purple-900/50 text-purple-50 placeholder:text-purple-400"
              />
            </div>
          </div>
          <button
            onClick={() => setWithImage((v) => !v)}
            className={`flex w-full items-center justify-between rounded-xl border px-4 py-3 text-sm transition ${
              withImage ? "border-fuchsia-500/50 bg-fuchsia-500/10 text-fuchsia-300" : "border-purple-700 text-purple-300 hover:border-purple-600"
            }`}
          >
            <span>Attach an image</span>
            <span className="text-xs">{withImage ? "Attached" : "Optional"}</span>
          </button>
          {error && (
            <div className="rounded-lg border border-red-800/60 bg-red-950/40 px-3 py-2 text-sm text-red-300">
              {error}
            </div>
          )}
        </div>
        <div className="flex justify-end gap-2 border-t border-purple-800/60 px-5 py-4">
          <Button variant="outline" onClick={onClose} className="border-purple-700 text-purple-200">
            Cancel
          </Button>
          <Button onClick={submit} className="bg-gradient-to-r from-fuchsia-500 via-purple-500 to-violet-600 text-white hover:from-fuchsia-600 hover:via-purple-600 hover:to-violet-700">
            Publish
          </Button>
        </div>
      </div>
    </div>
  );
}

function ProfileView({
  viewingUid,
  posts,
  onOpenAuthor,
}: {
  viewingUid: string;
  posts: Post[];
  onOpenAuthor: (uid: string) => void;
}) {
  const { user, userById, toggleFollow, updateProfile } = useAuth();
  const profile = userById(viewingUid);
  const [editing, setEditing] = useState(false);
  const [bio, setBio] = useState(profile?.bio ?? "");
  const [displayName, setDisplayName] = useState(profile?.displayName ?? "");
  const [country, setCountry] = useState(profile?.country ?? "");

  if (!profile || !user) return <EmptyState label="Profile not found." />;
  const isMe = profile.uid === user.uid;
  const following = user.following.includes(profile.uid);

  const totalLikes = posts.reduce((sum, p) => sum + p.likes.length, 0);
  const totalViews = posts.reduce((sum, p) => sum + p.views, 0);
  const totalComments = posts.reduce((sum, p) => sum + p.comments.length, 0);

  const save = () => {
    updateProfile({
      bio: bio.trim(),
      displayName: displayName.trim() || profile.displayName,
      country: country.trim(),
    });
    setEditing(false);
    toast.success("Profile updated");
  };

  return (
    <div className="space-y-6">
      <div className="relative overflow-hidden rounded-2xl border border-purple-800/50 bg-purple-950/40">
        <div className="h-32 bg-gradient-to-r from-fuchsia-900/70 via-purple-800/50 to-violet-900/70" />
        <div className="px-6 pb-6">
          <div className="-mt-12 flex items-end gap-4">
            <Avatar className="h-24 w-24 border-4 border-purple-950">
              <AvatarFallback style={{ background: profile.photoColor }} className="text-2xl font-bold text-white">
                {initials(profile.displayName)}
              </AvatarFallback>
            </Avatar>
            <div className="flex-1 pb-1">
              <div className="flex items-center gap-2">
                <h2 className="font-serif text-2xl font-bold text-fuchsia-50">{profile.displayName}</h2>
                {profile.verified && (
                  <span className="rounded-full bg-sky-500/20 px-2 py-0.5 text-xs text-sky-400">✓ Verified</span>
                )}
                {profile.isUpdater && (
                  <Badge variant="outline" className="border-fuchsia-500/40 text-xs text-fuchsia-400">Updater</Badge>
                )}
              </div>
              <p className="text-sm text-purple-400">@{profile.username}</p>
            </div>
            <div className="pb-1">
              {isMe ? (
                <Button
                  variant="outline"
                  onClick={() => setEditing((e) => !e)}
                  className="border-purple-700 text-purple-200"
                >
                  <Pencil className="h-4 w-4" /> Edit profile
                </Button>
              ) : (
                <Button
                  onClick={() => toggleFollow(profile.uid)}
                  className={following ? "border border-purple-700 bg-transparent text-purple-200 hover:bg-purple-900/60" : "bg-gradient-to-r from-fuchsia-500 to-violet-600 text-white hover:from-fuchsia-600 hover:to-violet-700"}
                >
                  {following ? "Following" : "Follow"}
                </Button>
              )}
            </div>
          </div>

          {editing ? (
            <div className="mt-5 space-y-3 rounded-xl border border-purple-800/50 bg-purple-950/60 p-4">
              <div className="space-y-2">
                <Label className="text-purple-200">Display name</Label>
                <Input value={displayName} onChange={(e) => setDisplayName(e.target.value)} className="border-purple-700 bg-purple-900/50 text-purple-50" />
              </div>
              <div className="space-y-2">
                <Label className="text-purple-200">Bio</Label>
                <Textarea value={bio} onChange={(e) => setBio(e.target.value)} rows={3} className="border-purple-700 bg-purple-900/50 text-purple-50" />
              </div>
              <div className="space-y-2">
                <Label className="text-purple-200">Country</Label>
                <Input value={country} onChange={(e) => setCountry(e.target.value)} className="border-purple-700 bg-purple-900/50 text-purple-50" />
              </div>
              <div className="flex gap-2">
                <Button onClick={save} className="bg-gradient-to-r from-fuchsia-500 to-violet-600 text-white hover:from-fuchsia-600 hover:to-violet-700">Save</Button>
                <Button variant="outline" onClick={() => setEditing(false)} className="border-purple-700 text-purple-200">Cancel</Button>
              </div>
            </div>
          ) : (
            <p className="mt-4 text-sm text-purple-200">{profile.bio || "No bio yet."}</p>
          )}

          <div className="mt-4 flex flex-wrap items-center gap-4 text-sm text-purple-300">
            {profile.country && <span>📍 {profile.country}</span>}
            <span>Joined {new Date(profile.joinedAt).toLocaleDateString()}</span>
            <span><strong className="text-purple-100">{profile.followers.length}</strong> followers</span>
            <span><strong className="text-purple-100">{profile.following.length}</strong> following</span>
            <span><strong className="text-purple-100">{posts.length}</strong> updates</span>
          </div>
        </div>
      </div>

      {isMe && (
        <div className="grid grid-cols-3 gap-3">
          {[
            { label: "Total likes", value: totalLikes, color: "text-rose-400" },
            { label: "Total comments", value: totalComments, color: "text-sky-400" },
            { label: "Total views", value: totalViews, color: "text-emerald-400" },
          ].map((s) => (
            <Card key={s.label} className="border-purple-800/50 bg-purple-950/40">
              <CardContent className="p-4">
                <div className={`font-serif text-2xl font-bold ${s.color}`}>{s.value}</div>
                <div className="text-xs text-purple-400">{s.label}</div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      <section className="space-y-3">
        <h3 className="font-serif text-lg font-bold text-purple-50">Updates</h3>
        {posts.length === 0 ? (
          <EmptyState label="No updates published yet." />
        ) : (
          posts.map((p) => <PostCard key={p.id} post={p} onOpenAuthor={onOpenAuthor} />)
        )}
      </section>
    </div>
  );
}