import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent } from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useAuth } from "@/lib/store";
import { Flame, Loader2, Mail, Lock, User as UserIcon, AtSign, ArrowLeft } from "lucide-react";
import { toast } from "sonner";

const MONTHS = [
  "January", "February", "March", "April", "May", "June",
  "July", "August", "September", "October", "November", "December",
];

export function AuthScreen() {
  const { login, register } = useAuth();
  const [mode, setMode] = useState<"login" | "register">("login");

  // login state
  const [loginEmail, setLoginEmail] = useState("");
  const [loginPassword, setLoginPassword] = useState("");

  // register state (X-style multi-step)
  const [step, setStep] = useState(0);
  const [displayName, setDisplayName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [username, setUsername] = useState("");
  const [month, setMonth] = useState("");
  const [day, setDay] = useState("");
  const [year, setYear] = useState("");

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const resetRegister = () => {
    setStep(0);
    setDisplayName("");
    setEmail("");
    setPassword("");
    setUsername("");
    setMonth("");
    setDay("");
    setYear("");
    setError("");
  };

  const doLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    if (!loginEmail || !loginPassword) return setError("Please enter your email and password.");
    setLoading(true);
    try {
      await login(loginEmail, loginPassword);
      toast.success("Welcome back to Xero");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Something went wrong.");
    } finally {
      setLoading(false);
    }
  };

  const nextStep = () => {
    setError("");
    if (step === 0) {
      if (displayName.trim().length < 2) return setError("Please enter your name.");
      setStep(1);
    } else if (step === 1) {
      if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) return setError("Please enter a valid email address.");
      setStep(2);
    } else if (step === 2) {
      if (password.length < 8) return setError("Password must be at least 8 characters.");
      setStep(3);
    } else if (step === 3) {
      if (username.trim().length < 3) return setError("Username must be at least 3 characters.");
      if (!/^[a-zA-Z0-9_]+$/.test(username)) return setError("Username can only contain letters, numbers, and underscores.");
      setStep(4);
    }
  };

  const finishRegister = async () => {
    setError("");
    const d = parseInt(day, 10);
    const y = parseInt(year, 10);
    if (!month || !day || !year) return setError("Please select your full birth date.");
    if (isNaN(d) || d < 1 || d > 31) return setError("Please enter a valid day.");
    if (isNaN(y) || y < 1900 || y > new Date().getFullYear()) return setError("Please enter a valid year.");
    setLoading(true);
    try {
      await register(username.trim(), displayName.trim(), email.trim(), password);
      toast.success("Account created — welcome to Xero!");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Something went wrong.");
    } finally {
      setLoading(false);
    }
  };

  const stepTitles = [
    "Create your account",
    "Add your email",
    "Set a password",
    "Choose a username",
    "Add your birth date",
  ];

  return (
    <div className="relative min-h-screen overflow-hidden bg-gradient-to-br from-purple-950 via-fuchsia-950 to-violet-950 text-purple-50">
      <div className="pointer-events-none absolute -top-40 -left-40 h-96 w-96 rounded-full bg-fuchsia-600/30 blur-3xl" />
      <div className="pointer-events-none absolute top-1/3 -right-40 h-96 w-96 rounded-full bg-violet-600/30 blur-3xl" />
      <div className="pointer-events-none absolute -bottom-40 left-1/3 h-96 w-96 rounded-full bg-purple-500/20 blur-3xl" />

      <div className="relative mx-auto grid min-h-screen max-w-6xl grid-cols-1 items-center gap-12 px-6 py-12 lg:grid-cols-2">
        <div className="hidden flex-col gap-6 lg:flex">
          <div className="flex items-center gap-3">
            <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-gradient-to-br from-fuchsia-500 via-purple-500 to-violet-600 shadow-lg shadow-purple-900/50">
              <Flame className="h-7 w-7 text-white" />
            </div>
            <span className="font-serif text-3xl font-bold tracking-tight text-fuchsia-50">Xero</span>
          </div>
          <h1 className="font-serif text-5xl font-bold leading-tight text-fuchsia-50">
            Discover what the world is <span className="bg-gradient-to-r from-fuchsia-400 via-purple-300 to-violet-400 bg-clip-text text-transparent">rising toward</span>.
          </h1>
          <p className="max-w-md text-lg text-purple-200/80">
            A global trend discovery and social platform. Anyone can become an updater. Follow the
            signal, not the noise.
          </p>
          <div className="mt-4 grid grid-cols-3 gap-4">
            {[
              { k: "16", v: "Categories" },
              { k: "Live", v: "Trend ranking" },
              { k: "Open", v: "For updaters" },
            ].map((s) => (
              <div key={s.v} className="rounded-xl border border-purple-800/60 bg-purple-900/40 p-4 backdrop-blur">
                <div className="font-serif text-2xl font-bold text-fuchsia-400">{s.k}</div>
                <div className="text-xs text-purple-300">{s.v}</div>
              </div>
            ))}
          </div>
        </div>

        <Card className="border-purple-800/60 bg-purple-950/70 shadow-2xl backdrop-blur">
          <CardContent className="p-8">
            <div className="mb-6 flex items-center gap-3 lg:hidden">
              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-fuchsia-500 via-purple-500 to-violet-600">
                <Flame className="h-6 w-6 text-white" />
              </div>
              <span className="font-serif text-2xl font-bold text-fuchsia-50">Xero</span>
            </div>

            {mode === "login" ? (
              <>
                <div className="mb-6 flex rounded-xl bg-purple-900/60 p-1">
                  <button
                    onClick={() => { setMode("login"); setError(""); }}
                    className="flex-1 rounded-lg bg-gradient-to-r from-fuchsia-500 to-violet-600 py-2 text-sm font-medium text-white shadow"
                  >
                    Sign in
                  </button>
                  <button
                    onClick={() => { setMode("register"); resetRegister(); }}
                    className="flex-1 rounded-lg py-2 text-sm font-medium text-purple-300 transition hover:text-purple-100"
                  >
                    Create account
                  </button>
                </div>

                <form onSubmit={doLogin} className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="loginEmail" className="text-purple-200">Email</Label>
                    <div className="relative">
                      <Mail className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-purple-400" />
                      <Input
                        id="loginEmail"
                        type="email"
                        value={loginEmail}
                        onChange={(e) => setLoginEmail(e.target.value)}
                        placeholder="you@example.com"
                        className="border-purple-700 bg-purple-900/60 pl-9 text-purple-50 placeholder:text-purple-400"
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="loginPassword" className="text-purple-200">Password</Label>
                    <div className="relative">
                      <Lock className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-purple-400" />
                      <Input
                        id="loginPassword"
                        type="password"
                        value={loginPassword}
                        onChange={(e) => setLoginPassword(e.target.value)}
                        placeholder="At least 8 characters"
                        className="border-purple-700 bg-purple-900/60 pl-9 text-purple-50 placeholder:text-purple-400"
                      />
                    </div>
                  </div>

                  {error && (
                    <div className="rounded-lg border border-red-800/60 bg-red-950/40 px-3 py-2 text-sm text-red-300">
                      {error}
                    </div>
                  )}

                  <Button
                    type="submit"
                    disabled={loading}
                    className="w-full bg-gradient-to-r from-fuchsia-500 via-purple-500 to-violet-600 py-6 text-base font-semibold text-white hover:from-fuchsia-600 hover:via-purple-600 hover:to-violet-700"
                  >
                    {loading ? <Loader2 className="h-5 w-5 animate-spin" /> : "Sign in"}
                  </Button>
                </form>

                <p className="mt-4 text-center text-xs text-purple-400">
                  Try a seeded account: <span className="text-purple-200">novaflux@xero.app</span> / any 8+ char password
                </p>
              </>
            ) : (
              <>
                <div className="mb-6 flex items-center gap-3">
                  {step > 0 && (
                    <button
                      onClick={() => { setStep((s) => s - 1); setError(""); }}
                      className="rounded-lg p-1.5 text-purple-300 transition hover:bg-purple-900/60 hover:text-purple-100"
                    >
                      <ArrowLeft className="h-5 w-5" />
                    </button>
                  )}
                  <div className="flex-1">
                    <h2 className="font-serif text-xl font-bold text-fuchsia-50">{stepTitles[step]}</h2>
                    <div className="mt-2 flex gap-1">
                      {[0, 1, 2, 3, 4].map((i) => (
                        <div
                          key={i}
                          className={`h-1 flex-1 rounded-full transition ${
                            i <= step ? "bg-gradient-to-r from-fuchsia-500 to-violet-500" : "bg-purple-800"
                          }`}
                        />
                      ))}
                    </div>
                  </div>
                </div>

                <div className="space-y-4">
                  {step === 0 && (
                    <div className="space-y-2">
                      <Label htmlFor="displayName" className="text-purple-200">Name</Label>
                      <div className="relative">
                        <UserIcon className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-purple-400" />
                        <Input
                          id="displayName"
                          value={displayName}
                          onChange={(e) => setDisplayName(e.target.value)}
                          placeholder="Nova Flux"
                          autoFocus
                          className="border-purple-700 bg-purple-900/60 pl-9 text-purple-50 placeholder:text-purple-400"
                        />
                      </div>
                    </div>
                  )}

                  {step === 1 && (
                    <div className="space-y-2">
                      <Label htmlFor="email" className="text-purple-200">Email</Label>
                      <div className="relative">
                        <Mail className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-purple-400" />
                        <Input
                          id="email"
                          type="email"
                          value={email}
                          onChange={(e) => setEmail(e.target.value)}
                          placeholder="you@example.com"
                          autoFocus
                          className="border-purple-700 bg-purple-900/60 pl-9 text-purple-50 placeholder:text-purple-400"
                        />
                      </div>
                    </div>
                  )}

                  {step === 2 && (
                    <div className="space-y-2">
                      <Label htmlFor="password" className="text-purple-200">Password</Label>
                      <div className="relative">
                        <Lock className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-purple-400" />
                        <Input
                          id="password"
                          type="password"
                          value={password}
                          onChange={(e) => setPassword(e.target.value)}
                          placeholder="At least 8 characters"
                          autoFocus
                          className="border-purple-700 bg-purple-900/60 pl-9 text-purple-50 placeholder:text-purple-400"
                        />
                      </div>
                    </div>
                  )}

                  {step === 3 && (
                    <div className="space-y-2">
                      <Label htmlFor="username" className="text-purple-200">Username</Label>
                      <div className="relative">
                        <AtSign className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-purple-400" />
                        <Input
                          id="username"
                          value={username}
                          onChange={(e) => setUsername(e.target.value)}
                          placeholder="novaflux"
                          autoFocus
                          className="border-purple-700 bg-purple-900/60 pl-9 text-purple-50 placeholder:text-purple-400"
                        />
                      </div>
                    </div>
                  )}

                  {step === 4 && (
                    <div className="space-y-3">
                      <Label className="text-purple-200">Date of birth</Label>
                      <p className="text-xs text-purple-400">
                        This helps us keep Xero safe and personalized. It won't be shown publicly.
                      </p>
                      <div className="grid grid-cols-3 gap-2">
                        <Select value={month} onValueChange={setMonth}>
                          <SelectTrigger className="border-purple-700 bg-purple-900/60 text-purple-50">
                            <SelectValue placeholder="Month" />
                          </SelectTrigger>
                          <SelectContent className="border-purple-700 bg-purple-950 text-purple-50">
                            {MONTHS.map((m, i) => (
                              <SelectItem key={m} value={String(i + 1)}>{m}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <Input
                          value={day}
                          onChange={(e) => setDay(e.target.value.replace(/\D/g, "").slice(0, 2))}
                          placeholder="Day"
                          className="border-purple-700 bg-purple-900/60 text-purple-50 placeholder:text-purple-400"
                        />
                        <Input
                          value={year}
                          onChange={(e) => setYear(e.target.value.replace(/\D/g, "").slice(0, 4))}
                          placeholder="Year"
                          className="border-purple-700 bg-purple-900/60 text-purple-50 placeholder:text-purple-400"
                        />
                      </div>
                    </div>
                  )}

                  {error && (
                    <div className="rounded-lg border border-red-800/60 bg-red-950/40 px-3 py-2 text-sm text-red-300">
                      {error}
                    </div>
                  )}

                  {step < 4 ? (
                    <Button
                      onClick={nextStep}
                      className="w-full bg-gradient-to-r from-fuchsia-500 via-purple-500 to-violet-600 py-6 text-base font-semibold text-white hover:from-fuchsia-600 hover:via-purple-600 hover:to-violet-700"
                    >
                      Next
                    </Button>
                  ) : (
                    <Button
                      onClick={finishRegister}
                      disabled={loading}
                      className="w-full bg-gradient-to-r from-fuchsia-500 via-purple-500 to-violet-600 py-6 text-base font-semibold text-white hover:from-fuchsia-600 hover:via-purple-600 hover:to-violet-700"
                    >
                      {loading ? <Loader2 className="h-5 w-5 animate-spin" /> : "Create account"}
                    </Button>
                  )}

                  <button
                    onClick={() => { setMode("login"); resetRegister(); }}
                    className="w-full text-center text-xs text-purple-400 transition hover:text-purple-200"
                  >
                    Already have an account? Sign in
                  </button>
                </div>
              </>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}