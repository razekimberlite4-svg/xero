import { useState } from "react";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import {
  Heart,
  MessageCircle,
  Share2,
  Bookmark,
  Eye,
  Flag,
  Trash2,
  ExternalLink,
  TrendingUp,
  Sparkles,
  Flame,
  RotateCcw,
} from "lucide-react";
import {
  useAuth,
  timeAgo,
  initials,
  trendingScore,
  risingScore,
  trendLabel,
  type Post,
} from "@/lib/store";
import { toast } from "sonner";

const LABEL_STYLES: Record<string, { cls: string; icon: React.ReactNode }> = {
  New: { cls: "bg-emerald-500/15 text-emerald-400 border-emerald-500/30", icon: <Sparkles className="h-3 w-3" /> },
  Rising: { cls: "bg-fuchsia-500/15 text-fuchsia-400 border-fuchsia-500/30", icon: <TrendingUp className="h-3 w-3" /> },
  Popular: { cls: "bg-purple-500/15 text-purple-400 border-purple-500/30", icon: <Flame className="h-3 w-3" /> },
  Returning: { cls: "bg-violet-500/15 text-violet-400 border-violet-500/30", icon: <RotateCcw className="h-3 w-3" /> },
};

export function PostCard({ post, onOpenAuthor }: { post: Post; onOpenAuthor?: (uid: string) => void }) {
  const {
    user,
    userById,
    toggleLike,
    addComment,
    deleteComment,
    sharePost,
    toggleSave,
    reportPost,
    deletePost,
    viewPost,
  } = useAuth();
  const [showComments, setShowComments] = useState(false);
  const [commentText, setCommentText] = useState("");

  const author = userById(post.authorId);
  const liked = user ? post.likes.includes(user.uid) : false;
  const saved = user ? user.savedPosts.includes(post.id) : false;
  const label = trendLabel(post);
  const score = Math.round(trendingScore(post));
  const rising = Math.round(risingScore(post));

  const handleShare = async () => {
    sharePost(post.id);
    const url = `${window.location.origin}/#post-${post.id}`;
    try {
      if (navigator.share) {
        await navigator.share({ title: post.title, text: post.body, url });
      } else {
        await navigator.clipboard.writeText(url);
        toast.success("Link copied to clipboard");
      }
    } catch {
      /* user cancelled */
    }
  };

  return (
    <article className="group rounded-2xl border border-purple-800/50 bg-purple-950/40 p-5 shadow-sm transition hover:border-purple-600/60 hover:shadow-md">
      <div className="flex items-start gap-3">
        <button onClick={() => onOpenAuthor?.(post.authorId)} className="shrink-0">
          <Avatar className="h-11 w-11 border border-purple-700/60">
            <AvatarFallback style={{ background: author?.photoColor ?? "#a855f7" }} className="text-sm font-bold text-white">
              {initials(author?.displayName ?? "?")}
            </AvatarFallback>
          </Avatar>
        </button>
        <div className="min-w-0 flex-1">
          <div className="flex flex-wrap items-center gap-x-2 gap-y-1">
            <button
              onClick={() => onOpenAuthor?.(post.authorId)}
              className="font-semibold text-purple-50 hover:text-fuchsia-400"
            >
              {author?.displayName ?? "Unknown"}
            </button>
            {author?.verified && (
              <span className="rounded-full bg-sky-500/20 px-1.5 text-xs text-sky-400">✓</span>
            )}
            <span className="text-sm text-purple-400">@{author?.username}</span>
            <span className="text-purple-600">·</span>
            <span className="text-sm text-purple-400">{timeAgo(post.createdAt)}</span>
            {label && (
              <Badge variant="outline" className={`ml-auto gap-1 ${LABEL_STYLES[label].cls}`}>
                {LABEL_STYLES[label].icon}
                {label}
              </Badge>
            )}
          </div>

          <h3 className="mt-2 font-serif text-lg font-bold leading-snug text-purple-50">{post.title}</h3>
          <p className="mt-1.5 text-sm leading-relaxed text-purple-200">{post.body}</p>

          {post.imageSeed && (
            <div className="mt-3 overflow-hidden rounded-xl border border-purple-800/50">
              <div
                className="flex h-40 items-center justify-center bg-gradient-to-br from-fuchsia-900/50 via-purple-900 to-violet-900/50"
                aria-label="Post image"
              >
                <Flame className="h-10 w-10 text-fuchsia-500/60" />
              </div>
            </div>
          )}

          {post.link && (
            <a
              href={post.link}
              target="_blank"
              rel="noreferrer"
              className="mt-3 inline-flex items-center gap-1.5 text-sm text-fuchsia-400 hover:text-fuchsia-300"
            >
              <ExternalLink className="h-3.5 w-3.5" />
              {post.link}
            </a>
          )}

          <div className="mt-3 flex flex-wrap items-center gap-2">
            <Badge variant="outline" className="border-purple-700/60 bg-purple-900/50 text-purple-200">
              {post.category}
            </Badge>
            {post.hashtags.map((h) => (
              <span key={h} className="text-xs text-fuchsia-400/80">#{h}</span>
            ))}
            {post.source && <span className="text-xs text-purple-400">via {post.source}</span>}
          </div>

          <div className="mt-4 flex items-center gap-1 border-t border-purple-800/50 pt-3">
            <button
              onClick={() => toggleLike(post.id)}
              className={`flex items-center gap-1.5 rounded-lg px-2.5 py-1.5 text-sm transition ${
                liked ? "text-rose-400" : "text-purple-300 hover:bg-purple-900/60 hover:text-rose-400"
              }`}
            >
              <Heart className={`h-4 w-4 ${liked ? "fill-rose-400" : ""}`} />
              {post.likes.length}
            </button>
            <button
              onClick={() => setShowComments((s) => !s)}
              className="flex items-center gap-1.5 rounded-lg px-2.5 py-1.5 text-sm text-purple-300 transition hover:bg-purple-900/60 hover:text-sky-400"
            >
              <MessageCircle className="h-4 w-4" />
              {post.comments.length}
            </button>
            <button
              onClick={handleShare}
              className="flex items-center gap-1.5 rounded-lg px-2.5 py-1.5 text-sm text-purple-300 transition hover:bg-purple-900/60 hover:text-emerald-400"
            >
              <Share2 className="h-4 w-4" />
              {post.shares}
            </button>
            <button
              onClick={() => viewPost(post.id)}
              className="flex items-center gap-1.5 rounded-lg px-2.5 py-1.5 text-sm text-purple-400 transition hover:bg-purple-900/60"
              title="Mark as viewed"
            >
              <Eye className="h-4 w-4" />
              {post.views}
            </button>
            <div className="ml-auto flex items-center gap-1">
              <span className="hidden rounded-md bg-purple-900/60 px-2 py-1 text-xs text-purple-300 sm:inline">
                score {score}
                {rising > 0 && <span className="ml-1 text-fuchsia-400">↑{rising}</span>}
              </span>
              <button
                onClick={() => toggleSave(post.id)}
                className={`rounded-lg p-2 transition hover:bg-purple-900/60 ${
                  saved ? "text-amber-400" : "text-purple-400 hover:text-amber-400"
                }`}
                title={saved ? "Unsave" : "Save"}
              >
                <Bookmark className={`h-4 w-4 ${saved ? "fill-amber-400" : ""}`} />
              </button>
              {user?.uid === post.authorId ? (
                <button
                  onClick={() => {
                    deletePost(post.id);
                    toast.success("Update deleted");
                  }}
                  className="rounded-lg p-2 text-purple-400 transition hover:bg-purple-900/60 hover:text-red-400"
                  title="Delete"
                >
                  <Trash2 className="h-4 w-4" />
                </button>
              ) : (
                <button
                  onClick={() => {
                    reportPost(post.id);
                    toast.success("Reported. Thank you for keeping Xero clean.");
                  }}
                  className="rounded-lg p-2 text-purple-400 transition hover:bg-purple-900/60 hover:text-red-400"
                  title="Report"
                >
                  <Flag className="h-4 w-4" />
                </button>
              )}
            </div>
          </div>

          {showComments && (
            <div className="mt-3 space-y-3 border-t border-purple-800/50 pt-3">
              {post.comments.length === 0 && (
                <p className="text-sm text-purple-400">No comments yet. Start the conversation.</p>
              )}
              {post.comments.map((c) => {
                const cAuthor = userById(c.authorId);
                return (
                  <div key={c.id} className="flex items-start gap-2.5">
                    <Avatar className="h-7 w-7">
                      <AvatarFallback style={{ background: cAuthor?.photoColor ?? "#a855f7" }} className="text-xs text-white">
                        {initials(cAuthor?.displayName ?? "?")}
                      </AvatarFallback>
                    </Avatar>
                    <div className="flex-1 rounded-xl bg-purple-900/40 px-3 py-2">
                      <div className="flex items-center gap-2">
                        <span className="text-sm font-medium text-purple-100">{cAuthor?.displayName}</span>
                        <span className="text-xs text-purple-400">{timeAgo(c.createdAt)}</span>
                        {user?.uid === c.authorId && (
                          <button
                            onClick={() => deleteComment(post.id, c.id)}
                            className="ml-auto text-xs text-purple-400 hover:text-red-400"
                          >
                            delete
                          </button>
                        )}
                      </div>
                      <p className="mt-0.5 text-sm text-purple-200">{c.body}</p>
                    </div>
                  </div>
                );
              })}
              <div className="flex gap-2">
                <Input
                  value={commentText}
                  onChange={(e) => setCommentText(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === "Enter" && commentText.trim()) {
                      addComment(post.id, commentText.trim());
                      setCommentText("");
                    }
                  }}
                  placeholder="Add a comment…"
                  className="border-purple-700 bg-purple-900/50 text-purple-50 placeholder:text-purple-400"
                />
                <Button
                  onClick={() => {
                    if (commentText.trim()) {
                      addComment(post.id, commentText.trim());
                      setCommentText("");
                    }
                  }}
                  className="bg-gradient-to-r from-fuchsia-500 to-violet-600 hover:from-fuchsia-600 hover:to-violet-700"
                >
                  Post
                </Button>
              </div>
            </div>
          )}
        </div>
      </div>
    </article>
  );
}