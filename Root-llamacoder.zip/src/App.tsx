import { useEffect, useState } from "react";
import { Toaster } from "sonner";
import { AuthProvider, useAuth } from "@/lib/store";
import { AuthScreen } from "@/components/AuthScreen";
import { AppShell } from "@/components/AppShell";

function Root() {
  const { user, ready } = useAuth();
  const [booted, setBooted] = useState(false);

  useEffect(() => {
    if (ready) setBooted(true);
  }, [ready]);

  if (!booted) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-purple-950">
        <div className="flex flex-col items-center gap-4">
          <div className="h-12 w-12 animate-spin rounded-full border-2 border-fuchsia-500 border-t-transparent" />
          <p className="font-serif text-lg text-fuchsia-100">Igniting Xero…</p>
        </div>
      </div>
    );
  }

  return user ? <AppShell /> : <AuthScreen />;
}

export default function App() {
  return (
    <AuthProvider>
      <Root />
      <Toaster
        theme="dark"
        position="top-center"
        toastOptions={{
          style: {
            background: "#2e1065",
            border: "1px solid #7e22ce",
            color: "#faf5ff",
          },
        }}
      />
    </AuthProvider>
  );
}