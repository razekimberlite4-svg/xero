/**
 * Xero API client.
 *
 * Points at a backend you host (e.g. on Render). Set VITE_API_URL in your
 * environment, or replace the fallback below with your service URL.
 *
 * Expected backend endpoints (see README notes):
 *   POST   /auth/register   { username, displayName, email, password }
 *   POST   /auth/login      { email, password } -> { token, user }
 *   GET    /me              -> user
 *   GET    /posts?category=&cursor=  -> { posts, nextCursor }
 *   POST   /posts           { title, body, category, hashtags, ... }
 *   POST   /posts/:id/like
 *   POST   /posts/:id/comments { body }
 *   POST   /users/:id/follow
 *   GET    /users/:id
 */

const API_URL =
  (typeof import.meta !== "undefined" && (import.meta as any).env?.VITE_API_URL) ||
  "https://your-xero-backend.onrender.com";

let authToken: string | null = null;

export function setToken(token: string | null) {
  authToken = token;
  if (token) localStorage.setItem("xero-token", token);
  else localStorage.removeItem("xero-token");
}

export function loadToken() {
  authToken = localStorage.getItem("xero-token");
  return authToken;
}

async function request<T>(path: string, options: RequestInit = {}): Promise<T> {
  const res = await fetch(`${API_URL}${path}`, {
    ...options,
    headers: {
      "Content-Type": "application/json",
      ...(authToken ? { Authorization: `Bearer ${authToken}` } : {}),
      ...(options.headers ?? {}),
    },
  });
  if (!res.ok) {
    const text = await res.text().catch(() => "");
    throw new Error(text || `Request failed: ${res.status}`);
  }
  return res.json() as Promise<T>;
}

export const api = {
  register: (data: { username: string; displayName: string; email: string; password: string }) =>
    request<{ token: string; user: unknown }>("/auth/register", {
      method: "POST",
      body: JSON.stringify(data),
    }),
  login: (data: { email: string; password: string }) =>
    request<{ token: string; user: unknown }>("/auth/login", {
      method: "POST",
      body: JSON.stringify(data),
    }),
  me: () => request<unknown>("/me"),
  listPosts: (params: { category?: string; cursor?: string } = {}) => {
    const q = new URLSearchParams();
    if (params.category) q.set("category", params.category);
    if (params.cursor) q.set("cursor", params.cursor);
    return request<{ posts: unknown[]; nextCursor?: string }>(`/posts?${q.toString()}`);
  },
  createPost: (data: unknown) =>
    request<unknown>("/posts", { method: "POST", body: JSON.stringify(data) }),
  likePost: (id: string) => request<void>(`/posts/${id}/like`, { method: "POST" }),
  comment: (id: string, body: string) =>
    request<unknown>(`/posts/${id}/comments`, { method: "POST", body: JSON.stringify({ body }) }),
  follow: (id: string) => request<void>(`/users/${id}/follow`, { method: "POST" }),
  getUser: (id: string) => request<unknown>(`/users/${id}`),
};