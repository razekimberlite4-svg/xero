import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useReducer,
  type ReactNode,
} from "react";

/* ------------------------------------------------------------------ */
/* Types                                                               */
/* ------------------------------------------------------------------ */

export type Category =
  | "Fashion"
  | "Music"
  | "Movies & TV"
  | "Sports"
  | "Technology"
  | "Gaming"
  | "Business"
  | "Education"
  | "Science"
  | "Politics & World News"
  | "Entertainment"
  | "Memes & Viral"
  | "Lifestyle"
  | "Travel"
  | "Food"
  | "Other";

export const CATEGORIES: Category[] = [
  "Fashion",
  "Music",
  "Movies & TV",
  "Sports",
  "Technology",
  "Gaming",
  "Business",
  "Education",
  "Science",
  "Politics & World News",
  "Entertainment",
  "Memes & Viral",
  "Lifestyle",
  "Travel",
  "Food",
  "Other",
];

export interface User {
  uid: string;
  username: string;
  displayName: string;
  email: string;
  bio: string;
  country: string;
  photoColor: string;
  joinedAt: number;
  following: string[];
  followers: string[];
  savedPosts: string[];
  followedCategories: Category[];
  isUpdater: boolean;
  verified: boolean;
  isAdmin: boolean;
  notifPrefs: { follows: boolean; likes: boolean; comments: boolean };
}

export interface Post {
  id: string;
  authorId: string;
  title: string;
  body: string;
  category: Category;
  hashtags: string[];
  link?: string;
  imageSeed?: string;
  source?: string;
  createdAt: number;
  likes: string[];
  comments: Comment[];
  shares: number;
  views: number;
  reports: string[];
  engagementHistory: { t: number; score: number }[];
}

export interface Comment {
  id: string;
  authorId: string;
  body: string;
  createdAt: number;
  reports: string[];
}

export interface Notification {
  id: string;
  userId: string;
  type: "follow" | "like" | "comment" | "mention" | "system";
  text: string;
  postId?: string;
  createdAt: number;
  read: boolean;
}

interface State {
  users: User[];
  posts: Post[];
  notifications: Notification[];
  currentUid: string | null;
  ready: boolean;
}

/* ------------------------------------------------------------------ */
/* Seed data                                                           */
/* ------------------------------------------------------------------ */

const COLORS = [
  "#d946ef",
  "#a855f7",
  "#8b5cf6",
  "#c026d3",
  "#7c3aed",
  "#e879f9",
  "#9333ea",
  "#6366f1",
];

const HOUR = 3600_000;

function seedUsers(): User[] {
  const base = [
    { u: "novaflux", n: "Nova Flux", c: "Japan", b: "Tech & AI trend scout. I find the signal in the noise." },
    { u: "aurorabeats", n: "Aurora Beats", c: "Brazil", b: "Music curator. Global sounds, rising artists." },
    { u: "kiteandthread", n: "Kite & Thread", c: "Italy", b: "Fashion forecaster. Runway to street." },
    { u: "matchpoint", n: "Match Point", c: "Spain", b: "Sports desk. Live moments that move the world." },
    { u: "pixelpantry", n: "Pixel Pantry", c: "Canada", b: "Food, memes, and everything in between." },
  ];
  return base.map((x, i) => ({
    uid: `seed-${i}`,
    username: x.u,
    displayName: x.n,
    email: `${x.u}@xero.app`,
    bio: x.b,
    country: x.c,
    photoColor: COLORS[i % COLORS.length],
    joinedAt: Date.now() - (400 - i * 30) * HOUR,
    following: [],
    followers: [],
    savedPosts: [],
    followedCategories: [],
    isUpdater: true,
    verified: i < 2,
    isAdmin: false,
    notifPrefs: { follows: true, likes: true, comments: true },
  }));
}

function seedPosts(users: User[]): Post[] {
  const raw: Array<Partial<Post> & { authorId: string; title: string; body: string; category: Category; ageH: number }> = [
    { authorId: users[0].uid, title: "On-device AI models just crossed a real threshold", body: "Small language models running fully offline on phones are now good enough for daily use. This changes privacy, latency, and cost all at once.", category: "Technology", ageH: 3, hashtags: ["ai", "ondevice", "privacy"], shares: 42, views: 3200 },
    { authorId: users[1].uid, title: "A bedroom producer from Lagos is topping global charts", body: "Afrobeats fused with ambient electronica. Three weeks old, already in 40 countries' top 50.", category: "Music", ageH: 6, hashtags: ["afrobeats", "risingartist"], shares: 88, views: 7400 },
    { authorId: users[2].uid, title: "Quiet luxury is fading — texture is the new status", body: "Runways are moving from logos to fabric. Tonal layering, raw silk, and hand-stitched seams are the tell.", category: "Fashion", ageH: 12, hashtags: ["fashion", "runway"], shares: 31, views: 2100 },
    { authorId: users[3].uid, title: "That 97th-minute equalizer broke the internet", body: "Clip has 12M views in 90 minutes. The stadium audio alone is worth it.", category: "Sports", ageH: 2, hashtags: ["football", "viral"], shares: 210, views: 15400 },
    { authorId: users[4].uid, title: "The 'grocery haul' meme is back and it's better", body: "Gen Z is remixing the 2019 haul format with deadpan narration. Resurgence detected across three platforms.", category: "Memes & Viral", ageH: 20, hashtags: ["memes", "returning"], shares: 64, views: 5100 },
    { authorId: users[0].uid, title: "Open-source robotics kits are getting absurdly cheap", body: "A full 6-axis arm for under $400. Schools are going to eat this up.", category: "Science", ageH: 30, hashtags: ["robotics", "opensource"], shares: 27, views: 1800 },
    { authorId: users[1].uid, title: "Vinyl sales hit a 35-year high — again", body: "Physical media keeps winning. The interesting part is who's buying: under-25s.", category: "Music", ageH: 48, hashtags: ["vinyl", "returning"], shares: 19, views: 1200 },
    { authorId: users[3].uid, title: "Esports viewership is shifting to mobile-first", body: "Mobile titles now account for the majority of new competitive viewers in Southeast Asia.", category: "Gaming", ageH: 8, hashtags: ["esports", "mobile"], shares: 33, views: 2600 },
    { authorId: users[4].uid, title: "Street food cities you can actually afford this year", body: "A ranked list based on cost-per-meal, transit, and safety. No sponsored picks.", category: "Travel", ageH: 60, hashtags: ["travel", "streetfood"], shares: 51, views: 3900 },
    { authorId: users[2].uid, title: "The 4-day workweek is quietly becoming normal", body: "Not everywhere, but the trend line is unmistakable in mid-size firms.", category: "Business", ageH: 15, hashtags: ["work", "future"], shares: 40, views: 4100 },
  ];
  return raw.map((r, i) => {
    const created = Date.now() - r.ageH * HOUR;
    const likes = Array.from({ length: Math.round((r.shares ?? 20) * 1.6) }).map((_, k) => `seedliker-${i}-${k}`);
    return {
      id: `post-${i}`,
      authorId: r.authorId,
      title: r.title,
      body: r.body,
      category: r.category,
      hashtags: r.hashtags ?? [],
      link: undefined,
      imageSeed: i % 3 === 0 ? `phx-${i}` : undefined,
      source: undefined,
      createdAt: created,
      likes,
      comments: [],
      shares: r.shares ?? 0,
      views: r.views ?? 0,
      reports: [],
      engagementHistory: buildHistory(created, likes.length, r.shares ?? 0),
    };
  });
}

function buildHistory(created: number, likes: number, shares: number): { t: number; score: number }[] {
  const now = Date.now();
  const span = Math.max(now - created, HOUR);
  const points: { t: number; score: number }[] = [];
  const steps = 6;
  for (let i = 0; i <= steps; i++) {
    const t = created + (span * i) / steps;
    const frac = i / steps;
    const eased = Math.pow(frac, 1.6);
    points.push({ t, score: Math.round((likes * 1 + shares * 3) * eased) });
  }
  return points;
}

/* ------------------------------------------------------------------ */
/* Ranking algorithm (mirrors server-side Cloud Function logic)        */
/* ------------------------------------------------------------------ */

const HALF_LIFE_HOURS = 18;

export function trendingScore(post: Post, now = Date.now()): number {
  const ageHours = Math.max((now - post.createdAt) / HOUR, 0.1);
  const decay = Math.pow(0.5, ageHours / HALF_LIFE_HOURS);
  const uniqueLikers = new Set(post.likes).size;
  const uniqueCommenters = new Set(post.comments.map((c) => c.authorId)).size;
  const engagement = uniqueLikers * 1 + uniqueCommenters * 2.5 + post.shares * 3 + post.views * 0.02;
  const penalty = post.reports.length * 12;
  return Math.max(engagement * decay - penalty, 0);
}

export function risingScore(post: Post, now = Date.now()): number {
  const h = post.engagementHistory;
  if (h.length < 2) return 0;
  const recent = h.slice(-3);
  const first = recent[0];
  const last = recent[recent.length - 1];
  const dt = Math.max((last.t - first.t) / HOUR, 0.1);
  const growth = (last.score - first.score) / dt;
  const ageHours = Math.max((now - post.createdAt) / HOUR, 0.1);
  const freshness = Math.pow(0.5, ageHours / 48);
  return Math.max(growth * freshness, 0);
}

export function trendLabel(post: Post, now = Date.now()): "New" | "Rising" | "Popular" | "Returning" | null {
  const ageHours = (now - post.createdAt) / HOUR;
  const score = trendingScore(post, now);
  const rising = risingScore(post, now);
  if (ageHours < 6) return "New";
  if (rising > 4) return "Rising";
  if (score > 200) return "Popular";
  if (ageHours > 72 && rising > 1.5) return "Returning";
  return null;
}

/* ------------------------------------------------------------------ */
/* Reducer                                                             */
/* ------------------------------------------------------------------ */

type Action =
  | { type: "INIT"; users: User[]; posts: Post[]; currentUid: string | null }
  | { type: "SET_READY" }
  | { type: "LOGIN"; uid: string }
  | { type: "LOGOUT" }
  | { type: "REGISTER"; user: User }
  | { type: "UPDATE_USER"; uid: string; patch: Partial<User> }
  | { type: "ADD_POST"; post: Post }
  | { type: "UPDATE_POST"; id: string; patch: Partial<Post> }
  | { type: "DELETE_POST"; id: string }
  | { type: "TOGGLE_LIKE"; postId: string; uid: string }
  | { type: "ADD_COMMENT"; postId: string; comment: Comment }
  | { type: "DELETE_COMMENT"; postId: string; commentId: string }
  | { type: "SHARE_POST"; postId: string }
  | { type: "VIEW_POST"; postId: string }
  | { type: "TOGGLE_SAVE"; postId: string; uid: string }
  | { type: "TOGGLE_FOLLOW"; targetUid: string; uid: string }
  | { type: "TOGGLE_CATEGORY"; uid: string; category: Category }
  | { type: "REPORT_POST"; postId: string; uid: string }
  | { type: "ADD_NOTIFICATION"; n: Notification }
  | { type: "READ_NOTIFICATIONS"; uid: string };

function reducer(state: State, action: Action): State {
  switch (action.type) {
    case "INIT":
      return { ...state, users: action.users, posts: action.posts, currentUid: action.currentUid };
    case "SET_READY":
      return { ...state, ready: true };
    case "LOGIN":
      return { ...state, currentUid: action.uid };
    case "LOGOUT":
      return { ...state, currentUid: null };
    case "REGISTER":
      return { ...state, users: [...state.users, action.user], currentUid: action.user.uid };
    case "UPDATE_USER":
      return {
        ...state,
        users: state.users.map((u) => (u.uid === action.uid ? { ...u, ...action.patch } : u)),
      };
    case "ADD_POST":
      return { ...state, posts: [action.post, ...state.posts] };
    case "UPDATE_POST":
      return {
        ...state,
        posts: state.posts.map((p) => (p.id === action.id ? { ...p, ...action.patch } : p)),
      };
    case "DELETE_POST":
      return { ...state, posts: state.posts.filter((p) => p.id !== action.id) };
    case "TOGGLE_LIKE":
      return {
        ...state,
        posts: state.posts.map((p) => {
          if (p.id !== action.postId) return p;
          const has = p.likes.includes(action.uid);
          const likes = has ? p.likes.filter((l) => l !== action.uid) : [...p.likes, action.uid];
          const last = p.engagementHistory[p.engagementHistory.length - 1];
          const delta = has ? -1 : 1;
          const history = [...p.engagementHistory, { t: Date.now(), score: (last?.score ?? 0) + delta }];
          return { ...p, likes, engagementHistory: history };
        }),
      };
    case "ADD_COMMENT":
      return {
        ...state,
        posts: state.posts.map((p) =>
          p.id === action.postId ? { ...p, comments: [...p.comments, action.comment] } : p
        ),
      };
    case "DELETE_COMMENT":
      return {
        ...state,
        posts: state.posts.map((p) =>
          p.id === action.postId
            ? { ...p, comments: p.comments.filter((c) => c.id !== action.commentId) }
            : p
        ),
      };
    case "SHARE_POST":
      return {
        ...state,
        posts: state.posts.map((p) => (p.id === action.postId ? { ...p, shares: p.shares + 1 } : p)),
      };
    case "VIEW_POST":
      return {
        ...state,
        posts: state.posts.map((p) => (p.id === action.postId ? { ...p, views: p.views + 1 } : p)),
      };
    case "TOGGLE_SAVE":
      return {
        ...state,
        users: state.users.map((u) => {
          if (u.uid !== action.uid) return u;
          const has = u.savedPosts.includes(action.postId);
          return {
            ...u,
            savedPosts: has
              ? u.savedPosts.filter((s) => s !== action.postId)
              : [...u.savedPosts, action.postId],
          };
        }),
      };
    case "TOGGLE_FOLLOW": {
      const target = state.users.find((u) => u.uid === action.targetUid);
      if (!target || action.targetUid === action.uid) return state;
      const isFollowing = target.followers.includes(action.uid);
      return {
        ...state,
        users: state.users.map((u) => {
          if (u.uid === action.uid) {
            return {
              ...u,
              following: isFollowing
                ? u.following.filter((f) => f !== action.targetUid)
                : [...u.following, action.targetUid],
            };
          }
          if (u.uid === action.targetUid) {
            return {
              ...u,
              followers: isFollowing
                ? u.followers.filter((f) => f !== action.uid)
                : [...u.followers, action.uid],
            };
          }
          return u;
        }),
      };
    }
    case "TOGGLE_CATEGORY":
      return {
        ...state,
        users: state.users.map((u) => {
          if (u.uid !== action.uid) return u;
          const has = u.followedCategories.includes(action.category);
          return {
            ...u,
            followedCategories: has
              ? u.followedCategories.filter((c) => c !== action.category)
              : [...u.followedCategories, action.category],
          };
        }),
      };
    case "REPORT_POST":
      return {
        ...state,
        posts: state.posts.map((p) =>
          p.id === action.postId && !p.reports.includes(action.uid)
            ? { ...p, reports: [...p.reports, action.uid] }
            : p
        ),
      };
    case "ADD_NOTIFICATION":
      return { ...state, notifications: [action.n, ...state.notifications] };
    case "READ_NOTIFICATIONS":
      return {
        ...state,
        notifications: state.notifications.map((n) =>
          n.userId === action.uid ? { ...n, read: true } : n
        ),
      };
    default:
      return state;
  }
}

/* ------------------------------------------------------------------ */
/* Context                                                             */
/* ------------------------------------------------------------------ */

interface Ctx {
  state: State;
  user: User | null;
  ready: boolean;
  login: (email: string, password: string) => Promise<void>;
  register: (username: string, displayName: string, email: string, password: string) => Promise<void>;
  logout: () => void;
  updateProfile: (patch: Partial<User>) => void;
  createPost: (input: {
    title: string;
    body: string;
    category: Category;
    hashtags: string[];
    link?: string;
    source?: string;
    imageSeed?: string;
  }) => void;
  toggleLike: (postId: string) => void;
  addComment: (postId: string, body: string) => void;
  deleteComment: (postId: string, commentId: string) => void;
  sharePost: (postId: string) => void;
  viewPost: (postId: string) => void;
  toggleSave: (postId: string) => void;
  toggleFollow: (targetUid: string) => void;
  toggleCategory: (category: Category) => void;
  reportPost: (postId: string) => void;
  readNotifications: () => void;
  deletePost: (postId: string) => void;
  updatePost: (postId: string, patch: Partial<Post>) => void;
  userById: (uid: string) => User | undefined;
}

const StoreContext = createContext<Ctx | null>(null);

const STORAGE_KEY = "xero-state-v1";

export function AuthProvider({ children }: { children: ReactNode }) {
  const [state, dispatch] = useReducer(reducer, {
    users: [],
    posts: [],
    notifications: [],
    currentUid: null,
    ready: false,
  });

  useEffect(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) {
        const parsed = JSON.parse(raw) as State;
        dispatch({ type: "INIT", users: parsed.users, posts: parsed.posts, currentUid: parsed.currentUid });
      } else {
        const users = seedUsers();
        const posts = seedPosts(users);
        users[1].following = [users[0].uid];
        users[0].followers = [users[1].uid];
        dispatch({ type: "INIT", users, posts, currentUid: null });
      }
    } catch {
      const users = seedUsers();
      const posts = seedPosts(users);
      dispatch({ type: "INIT", users, posts, currentUid: null });
    }
    dispatch({ type: "SET_READY" });
  }, []);

  useEffect(() => {
    if (!state.ready) return;
    try {
      localStorage.setItem(
        STORAGE_KEY,
        JSON.stringify({ users: state.users, posts: state.posts, currentUid: state.currentUid })
      );
    } catch {
      /* ignore quota */
    }
  }, [state.users, state.posts, state.currentUid, state.ready]);

  const user = useMemo(
    () => state.users.find((u) => u.uid === state.currentUid) ?? null,
    [state.users, state.currentUid]
  );

  const userById = useCallback((uid: string) => state.users.find((u) => u.uid === uid), [state.users]);

  const notify = useCallback(
    (userId: string, type: Notification["type"], text: string, postId?: string) => {
      dispatch({
        type: "ADD_NOTIFICATION",
        n: {
          id: `n-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
          userId,
          type,
          text,
          postId,
          createdAt: Date.now(),
          read: false,
        },
      });
    },
    []
  );

  const login = useCallback(
    async (email: string, password: string) => {
      await new Promise((r) => setTimeout(r, 500));
      const found = state.users.find((u) => u.email.toLowerCase() === email.toLowerCase());
      if (!found) throw new Error("No account found with that email.");
      if (password.length < 8) throw new Error("Password must be at least 8 characters.");
      dispatch({ type: "LOGIN", uid: found.uid });
    },
    [state.users]
  );

  const register = useCallback(
    async (username: string, displayName: string, email: string, password: string) => {
      await new Promise((r) => setTimeout(r, 600));
      if (state.users.some((u) => u.username.toLowerCase() === username.toLowerCase())) {
        throw new Error("That username is already taken.");
      }
      if (state.users.some((u) => u.email.toLowerCase() === email.toLowerCase())) {
        throw new Error("An account with that email already exists.");
      }
      if (password.length < 8) throw new Error("Password must be at least 8 characters.");
      const newUser: User = {
        uid: `u-${Date.now()}`,
        username,
        displayName,
        email,
        bio: "",
        country: "",
        photoColor: COLORS[Math.floor(Math.random() * COLORS.length)],
        joinedAt: Date.now(),
        following: [],
        followers: [],
        savedPosts: [],
        followedCategories: [],
        isUpdater: true,
        verified: false,
        isAdmin: false,
        notifPrefs: { follows: true, likes: true, comments: true },
      };
      dispatch({ type: "REGISTER", user: newUser });
    },
    [state.users]
  );

  const logout = useCallback(() => dispatch({ type: "LOGOUT" }), []);

  const updateProfile = useCallback(
    (patch: Partial<User>) => {
      if (!user) return;
      dispatch({ type: "UPDATE_USER", uid: user.uid, patch });
    },
    [user]
  );

  const createPost = useCallback<Ctx["createPost"]>(
    (input) => {
      if (!user) return;
      const post: Post = {
        id: `post-${Date.now()}`,
        authorId: user.uid,
        title: input.title,
        body: input.body,
        category: input.category,
        hashtags: input.hashtags,
        link: input.link,
        imageSeed: input.imageSeed,
        source: input.source,
        createdAt: Date.now(),
        likes: [],
        comments: [],
        shares: 0,
        views: 0,
        reports: [],
        engagementHistory: [{ t: Date.now(), score: 0 }],
      };
      dispatch({ type: "ADD_POST", post });
    },
    [user]
  );

  const toggleLike = useCallback(
    (postId: string) => {
      if (!user) return;
      const post = state.posts.find((p) => p.id === postId);
      dispatch({ type: "TOGGLE_LIKE", postId, uid: user.uid });
      if (post && post.authorId !== user.uid && !post.likes.includes(user.uid)) {
        const author = state.users.find((u) => u.uid === post.authorId);
        if (author?.notifPrefs.likes) {
          notify(post.authorId, "like", `${user.displayName} liked your update`, postId);
        }
      }
    },
    [user, state.posts, state.users, notify]
  );

  const addComment = useCallback(
    (postId: string, body: string) => {
      if (!user) return;
      const comment: Comment = {
        id: `c-${Date.now()}`,
        authorId: user.uid,
        body,
        createdAt: Date.now(),
        reports: [],
      };
      dispatch({ type: "ADD_COMMENT", postId, comment });
      const post = state.posts.find((p) => p.id === postId);
      if (post && post.authorId !== user.uid) {
        const author = state.users.find((u) => u.uid === post.authorId);
        if (author?.notifPrefs.comments) {
          notify(post.authorId, "comment", `${user.displayName} commented on your update`, postId);
        }
      }
    },
    [user, state.posts, state.users, notify]
  );

  const deleteComment = useCallback(
    (postId: string, commentId: string) => dispatch({ type: "DELETE_COMMENT", postId, commentId }),
    []
  );

  const sharePost = useCallback((postId: string) => dispatch({ type: "SHARE_POST", postId }), []);
  const viewPost = useCallback((postId: string) => dispatch({ type: "VIEW_POST", postId }), []);
  const toggleSave = useCallback(
    (postId: string) => {
      if (!user) return;
      dispatch({ type: "TOGGLE_SAVE", postId, uid: user.uid });
    },
    [user]
  );

  const toggleFollow = useCallback(
    (targetUid: string) => {
      if (!user) return;
      const target = state.users.find((u) => u.uid === targetUid);
      dispatch({ type: "TOGGLE_FOLLOW", targetUid, uid: user.uid });
      if (target && !target.followers.includes(user.uid) && target.notifPrefs.follows) {
        notify(targetUid, "follow", `${user.displayName} started following you`);
      }
    },
    [user, state.users, notify]
  );

  const toggleCategory = useCallback(
    (category: Category) => {
      if (!user) return;
      dispatch({ type: "TOGGLE_CATEGORY", uid: user.uid, category });
    },
    [user]
  );

  const reportPost = useCallback(
    (postId: string) => {
      if (!user) return;
      dispatch({ type: "REPORT_POST", postId, uid: user.uid });
    },
    [user]
  );

  const readNotifications = useCallback(() => {
    if (!user) return;
    dispatch({ type: "READ_NOTIFICATIONS", uid: user.uid });
  }, [user]);

  const deletePost = useCallback((postId: string) => dispatch({ type: "DELETE_POST", id: postId }), []);
  const updatePost = useCallback(
    (postId: string, patch: Partial<Post>) => dispatch({ type: "UPDATE_POST", id: postId, patch }),
    []
  );

  const value: Ctx = {
    state,
    user,
    ready: state.ready,
    login,
    register,
    logout,
    updateProfile,
    createPost,
    toggleLike,
    addComment,
    deleteComment,
    sharePost,
    viewPost,
    toggleSave,
    toggleFollow,
    toggleCategory,
    reportPost,
    readNotifications,
    deletePost,
    updatePost,
    userById,
  };

  return <StoreContext.Provider value={value}>{children}</StoreContext.Provider>;
}

export function useAuth() {
  const ctx = useContext(StoreContext);
  if (!ctx) throw new Error("useAuth must be used within AuthProvider");
  return ctx;
}

export function timeAgo(ts: number): string {
  const diff = Date.now() - ts;
  const m = Math.floor(diff / 60000);
  if (m < 1) return "just now";
  if (m < 60) return `${m}m ago`;
  const h = Math.floor(m / 60);
  if (h < 24) return `${h}h ago`;
  const d = Math.floor(h / 24);
  if (d < 7) return `${d}d ago`;
  return new Date(ts).toLocaleDateString();
}

export function initials(name: string): string {
  return name
    .split(" ")
    .map((p) => p[0])
    .slice(0, 2)
    .join("")
    .toUpperCase();
}